// FormatLibrary 
// @author bodong 
// this is the wrapper of Format To impl
#pragma once

namespace FormatLibrary
{
    namespace Detail
    {
#define _FL_FORMAT_TO_INDEX_ 1
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 2
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 3
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 4
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 5
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 6
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 7
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 8
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 9
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 10
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 11
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 12
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 13
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 14
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_

#define _FL_FORMAT_TO_INDEX_ 15
#include "Format/FormatToInner.hpp"
#undef _FL_FORMAT_TO_INDEX_
    }
}