/*
* Copyright (c) 2017-2020 the BasicX authors
* All rights reserved.
*
* The project sponsor and lead author is Xu Rendong.
* E-mail: xrd@ustc.edu, QQ: 277195007, WeChat: ustc_xrd
* See the contributors file for names of other contributors.
*
* Commercial use of this code in source and binary forms is
* governed by a LGPL v3 license. You may get a copy from the
* root directory. Or else you should get a specific written
* permission from the project author.
*
* Individual and educational use of this code in source and
* binary forms is governed by a 3-clause BSD license. You may
* get a copy from the root directory. Certainly welcome you
* to contribute code of all sorts.
*
* Be sure to retain the above copyright notice and conditions.
*/

#ifndef BASICX_PLUGINS_PLUGINS_H
#define BASICX_PLUGINS_PLUGINS_H

#include <string>
#include <stdint.h> // int32_t, int64_t

#include <common/compile.h>
//#include <mission/mission.h> //mission//

namespace basicx {

	enum BASICX_PLUGINS_EXPIMP plugin_status {
		init = 0, load = 1, exec = 2, wait = 3, stop = 4, fail = 5, // 导入信息，已经加载，正常运行，等待运行，停止运行，发生异常
	};

	class BASICX_PLUGINS_EXPIMP Plugins_X {
	private:
		Plugins_X();

	public:
		Plugins_X( std::string plugin_name );
		virtual ~Plugins_X();

	public:
		virtual bool Initialize() = 0;
		virtual bool InitializeExt() = 0;
		virtual bool StartPlugin() = 0;
		virtual bool SuspendPlugin() = 0;
		virtual plugin_status GetPluginStatus() = 0;
		virtual bool ContinuePlugin() = 0;
		virtual bool StopPlugin() = 0;
		virtual bool UninitializeExt() = 0;
		virtual bool Uninitialize() = 0;
		virtual bool AssignTask( int32_t task_id, int32_t identity, int32_t code, int32_t func, std::string& data ) = 0;
	};

	class Plugins_P;

	class BASICX_PLUGINS_EXPIMP Plugins { // class Plugins : public Mission_X //mission//
	public:
		Plugins();
		~Plugins();

	public:
		static Plugins* GetInstance();

	public:
		void StartPlugins();
		bool IsPluginsStarted();

	public:
		bool LoadAll( std::string folder );
		bool UnloadAll();

		Plugins_X* GetPluginsX( const std::string& plugin_name ) const;
		void SetPluginsX( const std::string& plugin_name, Plugins_X* plugins_x );

		std::string GetPluginLocationByName( const std::string& plugin_name ) const;
		std::string GetPluginCfgFilePathByName( const std::string& plugin_name ) const;
		std::string GetPluginInfoFilePathByName( const std::string& plugin_name ) const;

	public:
		void ReloadPluginInfos( std::string folder ); // 目前未做互斥处理，不建议程序启动后运行过程中再被调用
		size_t GetPluginInfosNumber();
		std::string GetPluginName( size_t index ) const;
		std::string GetPluginVersion( size_t index ) const;
		std::string GetPluginCompatVersion( size_t index ) const;
		std::string GetPluginVendor( size_t index ) const;
		std::string GetPluginCopyright( size_t index ) const;
		std::string GetPluginLicense( size_t index ) const;
		std::string GetPluginCategory( size_t index ) const;
		std::string GetPluginDescription( size_t index ) const;
		std::string GetPluginUrl( size_t index ) const;
		bool CanPluginLoadByName( const std::string& plugin_name );
		bool CanPluginUnloadByName( const std::string& plugin_name );
		bool LoadPluginByName( const std::string& plugin_name ); // 未事先 加载 关联插件将失败
		bool UnloadPluginByName( const std::string& plugin_name ); // 未事先 卸载 关联插件将失败

	private:
		Plugins_P* m_plugins_p;
		static Plugins* m_instance;
	};

} // namespace basicx

#endif // BASICX_PLUGINS_PLUGINS_H
