# BasicX
V1.0.3 Build 20231130

© 2017-2023 Xu Rendong. All Rights Reserved.

### Project Summary
Basic Library.

### Contact Information
QQ: 277195007, WeChat: ustc_xrd, E-mail: xrd@ustc.edu
